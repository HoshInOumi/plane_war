import pygame
import music
# pygame 游戏引擎进行初始化
pygame.init()
pygame.mixer.init()

# 载入音乐
music.GameMusic.load('sound/game_music.ogg')
# 加载游戏各种声音
bullet_sound = music.GameSound('sound/bullet.wav')
bomb_sound = music.GameSound('sound/use_bomb.wav')
supply_sound = music.GameSound('sound/supply.wav')
get_bomb_sound = music.GameSound('sound/get_bomb.wav')
get_bullet_sound = music.GameSound('sound/get_bullet.wav')
upgrade_sound = music.GameSound('sound/upgrade.wav')
enemy3_fly_sound = music.GameSound('sound/enemy3_flying.wav')
enemy1_down_sound = music.GameSound('sound/enemy1_down.wav')
enemy2_down_sound = music.GameSound('sound/enemy2_down.wav')
enemy3_down_sound = music.GameSound('sound/enemy3_down.wav')
me_down_sound = music.GameSound('sound/me_down.wav')

# 定义颜色
BLACK = (0, 0, 0)
GREEN = (0, 255, 0)
RED = (255, 0, 0)
WHITE = (255, 255, 255)

# 窗口大小
bg_size = width, height = 480, 700
screen = pygame.display.set_mode(bg_size)
pygame.display.set_caption('飞机大战')

# 背景图片
background = pygame.image.load('images/background.png').convert()