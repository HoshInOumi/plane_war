import pygame


class GameMusic(object):
    def __init__(self):
        pass

    @staticmethod
    def load(filename):
        pygame.mixer.music.load(filename)
        pygame.mixer.music.set_volume(0.2)

    @staticmethod
    def set_volume(self, value):
        pygame.mixer.music.set_volume(value)
        self.value = value


class GameSound(object):
    def __init__(self, filename):
        self.sound = pygame.mixer.Sound(filename)
        self.sound.set_volume(0.2)

    def set_volume(self, value):
        self.sound.set_volume(value)

    def play(self, loops=0, max_time=0, fade_ms=0):
        self.sound.play(loops, max_time, fade_ms)

